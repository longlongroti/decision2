create definer = root@`%` view v_member_buy_sales as
select `member_buy_sales`.`fphm`       AS `FPHM`,
       `member_buy_sales`.`FATHERDW`   AS `MDDM`,
       `member_buy_sales`.`FATHERNAME` AS `MDNAME`,
       `member_buy_sales`.`HYDM`       AS `HYDM`,
       `member_buy_sales`.`HYNAME`     AS `HYNAME`,
       `member_buy_sales`.`buycount`   AS `buycount`,
       `member_buy_sales`.`buyhtamt`   AS `buyhtamt`,
       `member_buy_sales`.`buysl2`     AS `buysl2`,
       `member_buy_sales`.`sellcount`  AS `sellcount`,
       `member_buy_sales`.`sellhtamt`  AS `sellhtamt`,
       `member_buy_sales`.`sellsl2`    AS `sellsl2`,
       `member_buy_sales`.`cdate`      AS `cdate`,
       `member_buy_sales`.`vdate`      AS `vdate`
from (select `c`.`FPHM`       AS `fphm`,
             `m`.`FATHERDW`   AS `FATHERDW`,
             `m`.`FATHERNAME` AS `FATHERNAME`,
             `c`.`HYDM`       AS `HYDM`,
             `m`.`MBNAME`     AS `HYNAME`,
             1                AS `buycount`,
             `c`.`HTAMT`      AS `buyhtamt`,
             `c`.`SOURCE_NUM` AS `buysl2`,
             0                AS `sellcount`,
             0                AS `sellhtamt`,
             0                AS `sellsl2`,
             `c`.`CDATE`      AS `cdate`,
             `c`.`DATE02`     AS `vdate`
      from (`caigouec`.`ex_contract` `c`
             left join `caigouec`.`ex_menber` `m` on ((`m`.`HYDM` = `c`.`HYDM`)))
      where ((`c`.`STATUS` >= 200) and (`m`.`HYTYP2` = 3))
      group by `c`.`FPHM`, `c`.`HYDM`
      union all
      select `c`.`FPHM`       AS `fphm`,
             `m`.`FATHERDW`   AS `FATHERDW`,
             `m`.`FATHERNAME` AS `FATHERNAME`,
             `c`.`HZDM`       AS `HYDM`,
             `m`.`MBNAME`     AS `HYNAME`,
             0                AS `buycount`,
             0                AS `buyhtamt`,
             0                AS `buysl2`,
             1                AS `sellcount`,
             `c`.`HTAMT`      AS `sellhtamt`,
             `c`.`SOURCE_NUM` AS `sellsl2`,
             `c`.`CDATE`      AS `cdate`,
             `c`.`DATE02`     AS `vdate`
      from (`caigouec`.`ex_contract` `c`
             left join `caigouec`.`ex_menber` `m` on ((`m`.`HYDM` = `c`.`HZDM`)))
      where ((`c`.`STATUS` >= 200) and (`m`.`HYTYP2` = 3))
      group by `c`.`FPHM`, `c`.`HZDM`) `member_buy_sales`;

