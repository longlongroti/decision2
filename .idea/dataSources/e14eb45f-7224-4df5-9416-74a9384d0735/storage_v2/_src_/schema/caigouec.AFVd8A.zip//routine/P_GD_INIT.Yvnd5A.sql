create
  definer = root@`%` procedure P_GD_INIT(IN t int)
RUN_LABEL:
begin
	DECLARE tname varchar(80);
	DECLARE flag int;
	DECLARE done INT DEFAULT 0; 
	DECLARE C_SYSINIT CURSOR FOR select tname,flag from sys_init;
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
	

	set @num=0;
	select count(0) into @num from sys_init where tname not in (select table_name from information_schema.tables where table_schema=DataBase() and table_type='BASE TABLE');
	if @num>0 then
		SELECT 1001 AS RESULT_CODE,'存在超出数据库表范围的规则设置' AS ERROR_MSG;
		LEAVE RUN_LABEL;
	end if;
	
	set @num=0;
	select count(0) into @num from information_schema.tables where table_schema=DataBase() and table_type='BASE TABLE' and table_name not in (select tname from sys_init);
	if @num>0 then
		SELECT 1002 AS RESULT_CODE,'存在未设置初始化规则的表请检查' AS ERROR_MSG;
		LEAVE RUN_LABEL;
	end if;
	
	set @num=0;
	select count(0) into @num from sys_init where flag is null;
	if @num>0 then
		SELECT 1003 AS RESULT_CODE,'初始化规则表中存在未设置初始化规则的记录' AS ERROR_MSG;
		LEAVE RUN_LABEL;
	end if;
	
	OPEN  C_SYSINIT;  
	
	
	read_loop : LOOP 
		FETCH  NEXT from C_SYSINIT INTO tname,flag;
		
		
		IF done = 1 THEN 
			LEAVE read_loop;
		END IF;
		
	
			
			
			
			
	
	END LOOP;
	
	CLOSE C_SYSINIT;
end;

