create definer = root@`%` view v_ex_loginsession_allcount as
select `t`.`hydm`           AS `hydm`,
       max(`t`.`logintime`) AS `logintime`,
       max(`t`.`lasttime`)  AS `lasttime`,
       sum(`t`.`daycount`)  AS `allcount`
from `caigouec`.`v_ex_loginsession_count` `t`
group by `t`.`hydm`;

