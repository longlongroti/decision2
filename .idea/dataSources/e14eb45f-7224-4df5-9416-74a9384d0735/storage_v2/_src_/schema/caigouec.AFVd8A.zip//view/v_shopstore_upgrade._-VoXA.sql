create definer = root@`%` view v_shopstore_upgrade as
select `sh`.`HYDM`               AS `hydm`,
       `sh`.`STORENAME`          AS `STORENAME`,
       `tm`.`SHOPID`             AS `SHOPID`,
       `tm`.`TEMPLATE_ID`        AS `TEMPLATE_ID`,
       `tm`.`PAY_DATE`           AS `PAY_DATE`,
       `tm`.`EXPIES`             AS `EXPIES`,
       `tm`.`status`             AS `STATUS`,
       `tm`.`PAY_OPTNAME`        AS `PAY_OPTNAME`,
       `tm`.`TEMPLATE_MANAGE_ID` AS `TEMPLATE_MANAGE_ID`
from (`caigouec`.`ex_store_template_manage` `tm`
       left join `caigouec`.`ex_shopstore` `sh` on ((`tm`.`SHOPID` = `sh`.`SHOPID`)));

