create definer = root@`%` view v_ex_loginsession_count as select `caigouec`.`ex_loginsession_count`.`RQ`        AS `rq`,
                                                                 `caigouec`.`ex_loginsession_count`.`HYDM`      AS `hydm`,
                                                                 `caigouec`.`ex_loginsession_count`.`LOGINTIME` AS `logintime`,
                                                                 `caigouec`.`ex_loginsession_count`.`LASTTIME`  AS `lasttime`,
                                                                 `caigouec`.`ex_loginsession_count`.`DAYCOUNT`  AS `daycount`
                                                          from `caigouec`.`ex_loginsession_count`
                                                          union all
                                                          select str_to_date(date_format(
                                                                                 max(`caigouec`.`ex_loginsession`.`LOGINTIME`),
                                                                                 '%Y%m%d'), '%Y%m%d')          AS `rq`,
                                                                 `caigouec`.`ex_loginsession`.`HYDM`           AS `hydm`,
                                                                 max(`caigouec`.`ex_loginsession`.`LOGINTIME`) AS `logintime`,
                                                                 max(`caigouec`.`ex_loginsession`.`LASTTIME`)  AS `lasttime`,
                                                                 count(0)                                      AS `daycount`
                                                          from `caigouec`.`ex_loginsession`
                                                          where (`caigouec`.`ex_loginsession`.`STYP` = 1)
                                                          group by `caigouec`.`ex_loginsession`.`HYDM`,
                                                                   date_format(`caigouec`.`ex_loginsession`.`LOGINTIME`, '%Y%m%d')
                                                          order by `rq`, `hydm`;

