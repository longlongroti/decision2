create definer = root@`%` view v_exm_login_allcount as
select `t`.`userid`         AS `userid`,
       max(`t`.`logintime`) AS `logintime`,
       max(`t`.`lasttime`)  AS `lasttime`,
       sum(`t`.`daycount`)  AS `allcount`
from `caigouec`.`v_exm_login_count` `t`
group by `t`.`userid`;

