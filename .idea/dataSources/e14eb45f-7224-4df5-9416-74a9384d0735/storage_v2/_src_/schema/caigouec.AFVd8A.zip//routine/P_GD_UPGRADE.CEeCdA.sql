create
  definer = root@`%` procedure P_GD_UPGRADE()
RUN_LABEL:
begin
    /*************************************************************************************
     *  请注意：不要在本文件中填写对数据类的操作，本文件仅对数据库表结构或者存储过程、视图等脚本的操作
     * SQL 文件中，不要出现行注释
     *************************************************************************************/
        
        set @num=0;
            select count(0) into @num from ex_qxmx where action = '/exp/callback' and method = 'wcsms' and styp=1 and sid='M00000' ;
        if @num = 0 then
            INSERT INTO  ex_qxmx ( MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ( '0', '/exp/callback', 'wcsms', '0', '网超短信接口', '1', 'M00000');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_codes where TYP='模板字段' and code='$tenderNumber$' ;
        if @num = 0 then
            INSERT INTO ex_codes (TYP, CODE, VALUE, ISUSE, ORDERNO, ISCANSET, DISFLAG0) VALUES ('模板字段', '$tenderNumber$', 'tenderNumber', '1', '18', '0', '0' );
        end if;
        
        set @num=0;
	       select count(0) into @num from ex_qxsz where mkid='M040025' and sid='M00000' and isuse = '0';
	    if @num = 1 then
	         update ex_qxsz set isuse = '1' where mkid='M040025' and sid='M00000' and isuse = '0';
	    end if;

	    set @num=0;
	       select count(0) into @num from ex_qxsz where mkid='M04002505' and sid='M00000' and isuse = '0';
	    if @num = 1 then
	         update ex_qxsz set isuse = '2' where mkid='M04002505' and sid='M00000' and isuse = '0';
	    end if;
        
        set @num=0;
            select count(0) into @num from ex_xtmk where mid='B0105' and sid='B00001';
        if @num = 0 then
            INSERT INTO ex_xtmk ( MID, MNAME, STYP, ORDBY, SID) VALUES ( 'B0105', '监管大屏', '2', '300', 'B00001');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_qxsz where MKID='B010505' and STYP=2 and SID='B00001';
        if @num = 0 then
            INSERT INTO ex_qxsz (MKID, MID, MNAME, NAME, URL, INURL, ISUSE, ORDERNO, PARENT, STYP, SID, SUB_MENU_ID) 
            VALUES ('B010505', 'B0105', '监管大屏', '监管大屏', '/exr/bigscreen/index.htm', '', '1', '10', NULL, '2', 'B00001', NULL);
        end if;
        
        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exr/bigscreen' and method='index' and styp='2' and sid='B00001';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B010505', '/exr/bigscreen', 'index', 2, '监管大屏', 2, 'B00001');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exp/joint/tender' and method='getJoinTenders' and styp='1' and sid='M00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('M040025', '/exp/joint/tender', 'getJoinTenders', 2, 'Ajax获取招标编号list', 1, 'M00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/hangsource/manager' and method='toAudit' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B010305', '/exm/hangsource/manager', 'toAudit', 2, '跳转资源审核页面', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/hangsource/manager' and method='agree' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B010305', '/exm/hangsource/manager', 'agree', 2, '上架审核通过', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/hangsource/manager' and method='reject' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B010305', '/exm/hangsource/manager', 'reject', 2, '上架审核拒绝', 2, 'B00000');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_qxsz where MKID='B015505' and MID='B0155' and NAME='印章审核' and STYP=2 and SID='B00000';
        if @num =1 then
            update ex_qxsz set NAME='印章管理'  where MKID='B015505' and MID='B0155' and NAME='印章审核' and STYP=2 and SID='B00000';
        end if;

        set @num=0;
            select count(0) into @num from ex_qxsz where MKID='B01550515' and MID='B0155' and STYP=2 and SID='B00000';
        if @num = 0 then
            INSERT INTO ex_qxsz (MKID, MID, MNAME, NAME, URL, INURL, ISUSE, ORDERNO, PARENT, STYP, SID, SUB_MENU_ID) 
            VALUES ('B01550515', 'B0155', '签章管理', '签章账号删除', '', '', '2', '40', 'B015505', '2', 'B00000', NULL);
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/seal/manager' and method='toDeleteSeal' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B01550515', '/exm/seal/manager', 'toDeleteSeal', 2, '签章账户删除页面', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/seal/manager' and method='doDeleteSeal' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B01550515', '/exm/seal/manager', 'doDeleteSeal', 2, '签章账户删除操作', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/seal/manager' and method='showDelReason' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B01550515', '/exm/seal/manager', 'showDelReason', 2, '查看删除说明', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxsz where MKID='B01550520' and MID='B0155' and STYP=2 and SID='B00000';
        if @num = 0 then
            INSERT INTO ex_qxsz (MKID, MID, MNAME, NAME, URL, INURL, ISUSE, ORDERNO, PARENT, STYP, SID, SUB_MENU_ID) 
            VALUES ('B01550520', 'B0155', '签章管理', '实名认证初始化', '', '', '2', '50', 'B015505', '2', 'B00000', NULL);
        end if;

        set @num=0;
            select count(0) into @num from ex_qxsz where MKID='B01550525' and MID='B0155' and STYP=2 and SID='B00000';
        if @num = 0 then
            INSERT INTO ex_qxsz (MKID, MID, MNAME, NAME, URL, INURL, ISUSE, ORDERNO, PARENT, STYP, SID, SUB_MENU_ID) 
            VALUES ('B01550525', 'B0155', '签章管理', '印章复审', '', '', '2', '60', 'B015505', '2', 'B00000', NULL);
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/seal/manager' and method='IdInitialization' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B01550520', '/exm/seal/manager', 'IdInitialization', 2, '实名认证初始化', 2, 'B00000');
        end if;

        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/seal/manager' and method='doRetrial' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B01550525', '/exm/seal/manager', 'doRetrial', 2, '印章复审', 2, 'B00000');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=1;
        if @num = 1 then
             update ex_codes set isuse=0 where typ='合同模板类型' and code=1;
        end if;

        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=6 and value='西山煤电股份设备采购（防爆）合同';
        if @num = 1 then
             update ex_codes set value='设备采购（防爆）合同' where typ='合同模板类型' and code=6 and value='西山煤电股份设备采购（防爆）合同';
        end if;

        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=7 and value='西山煤电股份设备采购（非防爆）合同';
        if @num = 1 then
             update ex_codes set value='设备采购（非防爆）合同' where typ='合同模板类型' and code=7 and value='西山煤电股份设备采购（非防爆）合同';
        end if;
        
        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=8;
        if @num = 1 then
             update ex_codes set orderno=8,iscanset=1 where typ='合同模板类型' and code=8;
        end if;
        
        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=11;
        if @num =0 then
            INSERT INTO ex_codes(TYP, CODE, VALUE, ISUSE, ORDERNO, ISCANSET, DISFLAG0) VALUES ('合同模板类型', 11, '山西焦化专属模板', 1, 11, 1, 1);
        end if;

        set @num=0;
            select count(0) into @num from ex_codes where typ='合同模板类型' and code=12;
        if @num =0 then
            INSERT INTO ex_codes(TYP, CODE, VALUE, ISUSE, ORDERNO, ISCANSET, DISFLAG0) VALUES ('合同模板类型', 12, '材料类合同模板', 1, 12, 1, 1);
        end if;
        
        set @num=0;
            select count(0) into @num from ex_cssz where CSKEY='SPECIAL_MATERIALS_CODE';
		if @num = 0 then
		    INSERT INTO  ex_cssz(CSKEY, CSMC, CSVALUE, MRZ, REMARK, FLAG0) VALUES ('SPECIAL_MATERIALS_CODE', '特殊材料品种代码', ',130,51990,', NULL, NULL, 1);
		end if;
        
        set @num=0;
            select count(0) into @num from ex_qxmx where action='/exm/hangsource/manager' and method='toInfo' and styp='2' and sid='B00000';
        if @num =0 then
            INSERT INTO  ex_qxmx(MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ('B010305', '/exm/hangsource/manager', 'toInfo', 2, '资源详情', 2, 'B00000');
        end if;
        
        set @num=0;
            select count(0) into @num from ex_qxmx where action = '/exp/callback' and method = 'wcSynchronousLogout' and styp=1 and sid='M00000' ;
        if @num = 0 then
            INSERT INTO  ex_qxmx ( MKID, ACTION, METHOD, ACCESSTAG, REMARK, STYP, SID) VALUES ( '0', '/exp/callback', 'wcSynchronousLogout', '0', '主站与网超同步退出接口', '1', 'M00000');
        end if;
        
        set @num=0;
           select count(0) into @num from ex_qxsz where mkid='B010305' and mid='B0103' and styp = '2' and sid='B00000' and url='/exm/hangsource/manager/list.htm';
        if @num = 1 then
             update ex_qxsz set url='/exm/hangsource/manager/list.htm?status=100' where mkid='B010305' and mid='B0103' and styp = '2' and sid='B00000' and url='/exm/hangsource/manager/list.htm';
        end if;
        
    /************************************************************
      *   请保持本SQL语句放在本文件的最后
      *    给后台管理员赋所有权限
     ************************************************************/
    insert into ex_qxfp( mkid,MENBER,styp,sid)
    select mkid,'0000',styp,sid from ex_qxsz where mkid not in (select mkid from ex_qxfp where MENBER='0000' and styp=2) and isuse!=0 and styp=2;
end;

