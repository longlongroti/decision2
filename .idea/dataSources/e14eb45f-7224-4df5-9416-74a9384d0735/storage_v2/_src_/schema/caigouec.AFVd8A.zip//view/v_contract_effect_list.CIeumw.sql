create definer = root@`%` view v_contract_effect_list as
select `c`.`HYDM`         AS `hydm`,
       `c`.`HYNAME`       AS `HYNAME`,
       `c`.`HZDM`         AS `hzdm`,
       `c`.`HZNAME`       AS `HZNAME`,
       `c`.`HTAMT`        AS `htamt`,
       `c`.`FPHM`         AS `fphm`,
       max(`mx`.`DLNAME`) AS `dlname`,
       sum(`mx`.`SL2`)    AS `sl2`,
       `c`.`CDATE`        AS `cdate`,
       `c`.`DATE02`       AS `vdate`,
       `c`.`MDDM`         AS `MDDM`,
       `c`.`MDNAME`       AS `MDNAME`
from (`caigouec`.`ex_contract` `c`
       left join `caigouec`.`ex_contract_mx` `mx` on ((`c`.`FPHM` = `mx`.`FPHM`)))
where (`c`.`STATUS` >= 200)
group by `c`.`FPHM`;

