create definer = root@`%` view v_member_buy_sales_contrast as
select `member_buy_sales_contrast`.`FPHM`      AS `FPHM`,
       `member_buy_sales_contrast`.`HYDM`      AS `HYDM`,
       `member_buy_sales_contrast`.`HYNAME`    AS `HYNAME`,
       `member_buy_sales_contrast`.`PM`        AS `PM`,
       `member_buy_sales_contrast`.`RKMDH`     AS `RKMDH`,
       `member_buy_sales_contrast`.`CD`        AS `CD`,
       `member_buy_sales_contrast`.`GG`        AS `GG`,
       `member_buy_sales_contrast`.`buyhtamt`  AS `buyhtamt`,
       `member_buy_sales_contrast`.`buysl2`    AS `buysl2`,
       `member_buy_sales_contrast`.`sellhtamt` AS `sellhtamt`,
       `member_buy_sales_contrast`.`sellsl2`   AS `sellsl2`,
       `member_buy_sales_contrast`.`cdate`     AS `cdate`,
       `member_buy_sales_contrast`.`vdate`     AS `vdate`
from (select `c`.`FPHM`      AS `FPHM`,
             `c`.`HYDM`      AS `HYDM`,
             `c`.`HYNAME`    AS `HYNAME`,
             `mx`.`PM`       AS `PM`,
             `mx`.`RKMDH`    AS `RKMDH`,
             `mx`.`CD`       AS `CD`,
             `mx`.`GG`       AS `GG`,
             `c`.`HTAMT`     AS `buyhtamt`,
             sum(`mx`.`SL2`) AS `buysl2`,
             0               AS `sellhtamt`,
             0               AS `sellsl2`,
             `c`.`CDATE`     AS `cdate`,
             `c`.`DATE02`    AS `vdate`
      from (`caigouec`.`ex_contract` `c`
             left join `caigouec`.`ex_contract_mx` `mx` on ((`c`.`FPHM` = `mx`.`FPHM`)))
      where (`c`.`STATUS` >= 200)
      group by `c`.`FPHM`, `c`.`HYDM`, `mx`.`PM`, `mx`.`RKMDH`, `mx`.`CD`, `mx`.`GG`
      union all
      select `c`.`FPHM`      AS `FPHM`,
             `c`.`HZDM`      AS `HYDM`,
             `c`.`HZNAME`    AS `HYNAME`,
             `mx`.`PM`       AS `PM`,
             `mx`.`RKMDH`    AS `RKMDH`,
             `mx`.`CD`       AS `CD`,
             `mx`.`GG`       AS `GG`,
             0               AS `buyhtamt`,
             0               AS `buysl2`,
             `c`.`HTAMT`     AS `sellhtamt`,
             sum(`mx`.`SL2`) AS `sellsl2`,
             `c`.`CDATE`     AS `cdate`,
             `c`.`DATE02`    AS `vdate`
      from (`caigouec`.`ex_contract` `c`
             left join `caigouec`.`ex_contract_mx` `mx` on ((`c`.`FPHM` = `mx`.`FPHM`)))
      where (`c`.`STATUS` >= 200)
      group by `c`.`FPHM`, `c`.`HZDM`, `mx`.`PM`, `mx`.`RKMDH`, `mx`.`CD`, `mx`.`GG`) `member_buy_sales_contrast`;

