create
  definer = root@`%` function GET_PINYIN(P_NAME varchar(255)) returns varchar(255)
BEGIN
      DECLARE V_COMPARE VARCHAR(255);
      DECLARE V_RETURN VARCHAR(255);
      DECLARE I INT;
  
      SET I = 1;
      SET V_RETURN = '';
      while I < LENGTH(P_NAME) do
          SET V_COMPARE = SUBSTR(P_NAME, I, 1);
          IF (V_COMPARE != '') THEN
              #SET V_RETURN = CONCAT(V_RETURN, ',', V_COMPARE);
              SET V_RETURN = CONCAT(V_RETURN, GET_FRIST_PINYIN(V_COMPARE));
              #SET V_RETURN = GET_FRIST_PINYIN(V_COMPARE);
          END IF;
          SET I = I + 1;
      end while;
  
      IF (ISNULL(V_RETURN) or V_RETURN = '') THEN
          SET V_RETURN = P_NAME;
      END IF;
  
      RETURN V_RETURN;
  END;

