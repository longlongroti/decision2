create definer = root@`%` trigger update_archive_status_scarp
  after UPDATE
  on device_scarp
  for each row
BEGIN

IF NEW. STATUS = 2 THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,
		location_id,
		location_name,
		equipment_status,
		equipment_status_name,current_using_org, current_using_org_name
	) SELECT
		UUID(),
		a.device_id,
		b.material_name,
		'scrap',
		'9',
		'',
		'',
		'8',
		'8','',''
	FROM
		device_scarp_entry a
	LEFT JOIN device_archives b ON a.device_id = b.uuid
	WHERE
		a.device_scarp_id = OLD.UUID ;
	END
	IF ;
	END;

