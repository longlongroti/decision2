create definer = root@`%` trigger update_archive_status_receive
  after UPDATE
  on device_use
  for each row
BEGIN

IF NEW. STATUS = 2 AND OLD.STATUS !=2 THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,
		location_id,
		location_name,
		equipment_status,
		equipment_status_name,
		current_using_dept,
		current_using_dept_name,current_using_org, current_using_org_name
	) SELECT
		UUID(),
		a.device_id,
		b.material_name,
		'receive',
		'6',
		a.location_uuid,
		a.location_name,
		a.equ_status_code,
		a.equ_status_name,
		c.apply_org,
		c.apply_org_name,'',''
	FROM
		device_use_equipment a
	LEFT JOIN device_archives b ON a.device_id = b.uuid
	LEFT JOIN device_use c ON c.uuid = a.device_use_id
	WHERE
		a.device_use_id = OLD.UUID ;
	END
	IF ;
	END;

