create definer = root@`%` trigger update_archive_status_other
  after UPDATE
  on device_other
  for each row
BEGIN

IF NEW. STATUS = 2  and OLD.STATUS !=2  THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,
		location_id,
		location_name,
		equipment_status,
		equipment_status_name,current_using_dept, current_using_dept_name,current_using_org,current_using_org_name
	) SELECT
		UUID(),
		a.divice_uuid,
		b.material_name,
		'other',
		'12',
		a.func_position_target,
		a.func_position_target_name,
		a.device_status_target,
		a.device_status_target,a.use_dept_target,a.use_dept_target_name,a.use_org_target,a.use_org_target_name
	FROM
		device_other_details a
	LEFT JOIN device_archives b ON a.divice_uuid = b.uuid
	WHERE
		a.parent = OLD.UUID ;
	END
	IF ;
	END;

