create definer = root@`%` trigger update_archive_status_maintain
  after UPDATE
  on device_maintain
  for each row
BEGIN

IF NEW. STATUS = 2 AND OLD.STATUS !=2  THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,

		location_id,
		location_name,
		equipment_status,
		equipment_status_name,current_using_org, current_using_org_name
	) SELECT
		UUID(),
		a.device_id,
		b.material_name,
		'maintain',
		'10',

		a.func_position_target,
		a.func_position_target_name,
		a.device_status_target,
		a.device_status_target,'',''
	FROM
		device_maintain_equipment a
	LEFT JOIN device_archives b ON a.device_id = b.uuid
	WHERE
		a.device_maintain_id = OLD.UUID ;
	END
	IF ;
	END;

