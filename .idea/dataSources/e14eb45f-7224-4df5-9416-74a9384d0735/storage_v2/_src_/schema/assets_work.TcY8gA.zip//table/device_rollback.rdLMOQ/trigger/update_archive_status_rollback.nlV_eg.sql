create definer = root@`%` trigger update_archive_status_rollback
  after UPDATE
  on device_rollback
  for each row
BEGIN

IF NEW. STATUS = 2 AND OLD.STATUS !=2 THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,
		location_id,
		location_name,
		equipment_status,
		equipment_status_name,
		current_using_dept,
		current_using_dept_name,current_using_org, current_using_org_name
	) SELECT
		UUID(),
		a.device_id,
		b.material_name,
		'rollback',
		'7',
		a.func_position_target,
		a.func_position_target_name,
		a.device_status_target,
		a.device_status_target,
		c.fold_department_id,
		c.fold_department,'',''
	FROM
		device_rollback_entry a
	LEFT JOIN device_archives b ON a.device_id = b.uuid
	LEFT JOIN device_rollback c ON c.uuid = a.rollback_id
	WHERE
		a.rollback_id = OLD.UUID ;
	END
	IF ;
	END;

