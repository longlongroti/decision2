create
  definer = root@`%` procedure sbunlock(IN addtime varchar(50))
begin
    update jm_sb_mine_copy set if_lock = '0' where add_time = addtime;
END;

