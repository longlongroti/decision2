create
  definer = root@`%` procedure updatelock(IN addtime varchar(50))
BEGIN 
update jm_sb_mine_copy set if_lock = '1' where add_time = addtime;
END;

