create definer = root@`%` trigger update_archive_status_leaseback_storage
  after UPDATE
  on device_leaseback_storage
  for each row
BEGIN

IF NEW. STATUS = 2 AND OLD.STATUS  !=2 THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,

		location_name,
		location_id,
		equipment_status,
		current_using_dept,
		current_using_dept_name,
		current_using_org,
		current_using_org_name
	) SELECT
		UUID(),
		a.material_number,
		b.material_name,
		'inStorage',
		'5',

		'',
		'',
		'',
		'',
		'',
		c.rent_org,
		c.rent_org_name
	FROM
		device_leaseback_storage_details a
	LEFT JOIN device_archives b ON a.material_number = b.uuid
                  left join device_leaseback_storage c on a.leaseback_storage_id = c.uuid
	WHERE
		a.leaseback_storage_id = OLD.UUID ;
	END
	IF ;
	END;

