create definer = root@`%` trigger update_archive_status
  after UPDATE
  on device_archives
  for each row
begin
if NEW.status=2 and OLD.STATUS !=2 then
insert into device_archives_status(uuid,device_id,device_name,flow_type,flow_type_code,location_name,location_id
,equipment_status,current_using_dept,current_using_dept_name,current_using_org, current_using_org_name)
select UUID(), Old.uuid,material_name,'equipmentDoc','1',location_number_name,location_number,biz_status,lease_org,
       lease_org_name,using_dept,using_dept_name from device_archives where uuid = OLD.uuid;
end if;
end;

