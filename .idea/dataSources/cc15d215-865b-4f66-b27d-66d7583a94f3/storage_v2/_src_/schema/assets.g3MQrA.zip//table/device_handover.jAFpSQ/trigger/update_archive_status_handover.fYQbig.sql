create definer = root@`%` trigger update_archive_status_handover
  after UPDATE
  on device_handover
  for each row
BEGIN

IF NEW. STATUS = 2 AND OLD.STATUS !=2 THEN
	INSERT INTO device_archives_status (
		uuid,
		device_id,
		device_name,
		flow_type,
		flow_type_code,
		location_id,
		location_name,
		equipment_status,
		equipment_status_name,
		current_using_dept,
		current_using_dept_name,
                                    current_using_org, 
                                    current_using_org_name
	) SELECT
		UUID(),
		a.device_uuid,
		b.material_name,
		'handOver',
		'8',
		a.func_position_target,
		a.func_position_target_name,
		a.device_status_target,
		a.device_status_target,
		c.into_org,
		c.into_org_name,'',''
	FROM
		device_handover_details a
	LEFT JOIN device_archives b ON a.device_uuid = b.uuid
	LEFT JOIN device_handover c ON c.uuid = a.parent
	WHERE
		a.parent = OLD.UUID ;
	END
	IF ;
	END;

